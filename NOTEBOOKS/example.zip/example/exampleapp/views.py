from django.shortcuts import render, redirect
from .forms import FeedbackForm
from django.contrib import messages

def home(request):
    return render(request, 'home.html')

def feedback(request):
    if request.method == 'POST':
        form = FeedbackForm(request.POST)
        if form.is_valid():
            name = form.cleaned_data['name']
            messages.success(request, "Feedback sent successfully")
            return redirect('home')
    else: 
        form = FeedbackForm()
    return render(request, 'feedback.html', {'form': form})
        