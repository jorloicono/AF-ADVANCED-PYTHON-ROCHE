from django import forms

class FeedbackForm(forms.Form):
    name = forms.CharField(label = "Name", max_length = 255)
    email = forms.EmailField(label = "Email")
    mesage = forms.CharField(label = "Feedback", max_length = 255)